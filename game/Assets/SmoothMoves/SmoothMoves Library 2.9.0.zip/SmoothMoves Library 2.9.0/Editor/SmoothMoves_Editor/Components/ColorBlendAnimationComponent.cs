﻿using UnityEngine;
using UnityEditor;

namespace SmoothMoves
{
	public class ColorBlendAnimationComponent
	{ 
	}
}
